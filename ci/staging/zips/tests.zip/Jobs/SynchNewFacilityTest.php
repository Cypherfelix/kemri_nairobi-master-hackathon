<?php

namespace App\Jobs;

use PHPUnit\Framework\TestCase;

class SynchNewFacilityTest extends TestCase
{

}
